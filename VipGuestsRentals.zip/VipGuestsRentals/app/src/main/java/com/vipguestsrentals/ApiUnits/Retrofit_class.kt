import android.util.Log
import com.vipguestsrentals.Utils.AppConstants
import com.vipguestsrentals.Utils.SharedPref
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object Retrofit_class {
    val BAS_URL="https://jewellcart.in/"
    private  val httpLoggingInterceptor= HttpLoggingInterceptor{ message-> Log.e("Retrofit",message)}
        .setLevel(HttpLoggingInterceptor.Level.BODY)

    private  val client: OkHttpClient = OkHttpClient.Builder().addInterceptor(httpLoggingInterceptor)
        .connectTimeout(1, TimeUnit.MINUTES)
        .writeTimeout(1, TimeUnit.MINUTES)
        .readTimeout(1, TimeUnit.MINUTES).addInterceptor(Interceptor { chain: Interceptor.Chain ->
            val request = chain.request()
            val newRequest = request.newBuilder()
                .header(
                    "Authorization",
                    "Bearer " + SharedPref.instance.getToken(AppConstants.ACCESS_TOKEN)
                )
                .header(
                    "Accept",
                    "application/json"
                )
            chain.proceed(newRequest.build())
        })
        //this give us apis response on OkHttpClient in Logcat and Run.
        .addInterceptor(httpLoggingInterceptor).build()

    private  val retrofit: Retrofit = Retrofit.Builder().baseUrl(BAS_URL).client(client)
        .addConverterFactory(GsonConverterFactory.create()).build()

    val apiService: ApiInterface= retrofit.create(ApiInterface::class.java)
}

