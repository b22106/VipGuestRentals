package com.vipguestsrentals

import Retrofit_class
import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.vipguestsrentals.ModelClass.ChangePasswordModel
import com.vipguestsrentals.ModelClass.ImageModal
import com.vipguestsrentals.ModelClass.UserModel
import com.vipguestsrentals.Utils.AppConstants
import com.vipguestsrentals.Utils.SharedsCommon
import com.vipguestsrentals.databinding.FragmentEditProfileBinding
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response
import java.io.ByteArrayOutputStream
import java.io.File


class EditProfileFragment : Fragment() {
    lateinit var binding: FragmentEditProfileBinding
    private val pickImage = 100
    private val camerapickImage = 101
    private var imageUri: Uri? = null
    private lateinit var file: File
    lateinit var sharedPref: SharedsCommon


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding= FragmentEditProfileBinding.inflate(layoutInflater, container, false)


        sharedPref = SharedsCommon(requireContext())


        val abc = sharedPref.getImage(AppConstants.IMAGE)


        if (abc.toString().isNotEmpty()) {
            val b: ByteArray = Base64.decode(abc, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(b, 0, b.size)
            binding.profile.setImageBitmap(bitmap)
        }

        binding.changePassword.setOnClickListener {
            val intent = Intent(activity, Change_Password::class.java)
            startActivity(intent)
        }
        binding.profile.setOnClickListener {

            val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            startActivityForResult(gallery, pickImage)

            /* val camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
             startActivityForResult(camera, camerapickImage)*/
        }
        binding.saveEdit.setOnClickListener {
            if (binding.etFirstNameEdit.text.isEmpty()) {

                Toast.makeText(requireContext(), "Please Enter First Name", Toast.LENGTH_SHORT)
                    .show()

            } else if (binding.etLastNameEdit.text.isEmpty()) {

                Toast.makeText(requireContext(), "Please Enter Last Name", Toast.LENGTH_SHORT)
                    .show()

            } else if (binding.etEmailEdit.text.isEmpty()) {

                Toast.makeText(requireContext(), "Please Enter Email id", Toast.LENGTH_SHORT).show()

            } else {

                saveDetails(
                    binding.etFirstNameEdit.text.toString(),
                    binding.etLastNameEdit.text.toString(),
                    binding.etEmailEdit.text.toString()
                )

            }
        }
        getUsers()

        return binding.root
    }
    private fun SetProfileImage() {

        val requestBody =
            RequestBody.create("image/jpeg".toMediaTypeOrNull(), file)

        val filePart = MultipartBody.Part.createFormData(
            "profile_pic",
            file.name,
            requestBody
        )

        val model = Retrofit_class.apiService.updateImage(filePart)
        model.enqueue(object : retrofit2.Callback<ImageModal?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<ImageModal?>,
                response: Response<ImageModal?>
            ) {
                if (response.isSuccessful) {
                    val getlinksdata: ImageModal = response.body()!!
                    Toast.makeText(requireContext(), getlinksdata.message, Toast.LENGTH_SHORT)
                        .show()
                    context?.let { getImageUriFromBitmap(it,bitmap = null) }
                } else {
                    response.errorBody()?.let { body ->
                        try {
                            val resType = object : TypeToken<ImageModal>() {}.type
                            val errBody: ImageModal? =
                                Gson().fromJson(body.charStream(), resType)

                        } catch (_: Exception) {

                        }
                    }

                }
            }

            override fun onFailure(call: Call<ImageModal?>, t: Throwable) {
                Toast.makeText(requireContext(), "" + t, Toast.LENGTH_SHORT).show()
            }
        })

    }


    private fun getUsers() {

        val model = Retrofit_class.apiService.getuser(
        )
        model.enqueue(object : retrofit2.Callback<UserModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<UserModel?>,
                response: Response<UserModel?>
            ) {
                if (response.isSuccessful) {
                    val getlinksdata: UserModel? = response.body()!!
                    if (getlinksdata?.status == 201) {
                        binding.etFirstNameEdit.setText(getlinksdata.data.fname)
                        binding.etLastNameEdit.setText(getlinksdata.data.lname)
                        binding.etEmailEdit.setText(getlinksdata.data.email)
                        Toast.makeText(
                            requireContext(),
                            "Please Enter Email id" + getlinksdata.data.fname,
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            requireContext(),
                            getlinksdata?.message ?: "",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {
                    response.errorBody()?.let { body ->
                        try {
                            val resType = object : TypeToken<UserModel>() {}.type
                            val errBody: UserModel? =
                                Gson().fromJson(body.charStream(), resType)

                            Log.e("errorBody: ", "${errBody?.message}")
                            Toast.makeText(
                                requireContext(),
                                errBody?.message ?: "",
                                Toast.LENGTH_SHORT
                            ).show()

                        } catch (e: Exception) {
                            Toast.makeText(
                                requireContext(),
                                e.localizedMessage!!.toString(),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                }
            }

            override fun onFailure(call: Call<UserModel?>, t: Throwable) {
                Toast.makeText(requireContext(), "" + t, Toast.LENGTH_SHORT).show()
            }

        })

    }
    private fun saveDetails(fnames: String, lnames: String, emails: String) {
        val model =
            Retrofit_class.apiService.getprofileUpdate(fnames.trim(), lnames.trim(), emails.trim())
        model?.enqueue(object : retrofit2.Callback<ChangePasswordModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<ChangePasswordModel?>,
                response: Response<ChangePasswordModel?>
            ) {
                if (response.isSuccessful) {
                    val getlinksdata: ChangePasswordModel = response.body()!!
                    Toast.makeText(requireContext(), getlinksdata.message, Toast.LENGTH_SHORT)
                        .show()

                } else {
                    response.errorBody()?.let { body ->
                        try {
                            val resType = object : TypeToken<ChangePasswordModel>() {}.type
                            val errBody: ChangePasswordModel? =
                                Gson().fromJson(body.charStream(), resType)

                            Log.e("errorBody: ", "${errBody?.message}")
                            Toast.makeText(
                                requireContext(),
                                errBody?.message ?: "",
                                Toast.LENGTH_SHORT
                            ).show()

                        } catch (e: Exception) {
                            Log.e("errorBody: ", "${e.message}")
                            Toast.makeText(
                                requireContext(),
                                e.message!!.toString(),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                }
            }

            override fun onFailure(call: Call<ChangePasswordModel?>, t: Throwable) {
                Toast.makeText(requireContext(), "asdfghfdfsdasdfg" + t, Toast.LENGTH_SHORT).show()
            }

        })


    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == pickImage) {
            imageUri = data?.data
            binding.profile.setImageURI(imageUri)
            file = File(imageUri!!.path.toString())
            SetProfileImage()
            val bitmap: Bitmap =
                MediaStore.Images.Media.getBitmap(requireContext().getContentResolver(), imageUri)
           binding.profile.setImageBitmap(bitmap)
            val baos = ByteArrayOutputStream()

            Toast.makeText(requireContext(), "profile image upload", Toast.LENGTH_SHORT).show()

            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val b: ByteArray = baos.toByteArray()
            val encodedImage: String = Base64.encodeToString(b, Base64.DEFAULT)

            sharedPref.setImage(AppConstants.IMAGE, java.lang.String.valueOf(encodedImage))
        }
        if (resultCode == RESULT_OK && requestCode == camerapickImage) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            binding.profile.setImageBitmap(imageBitmap)

            val baos = ByteArrayOutputStream()
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val b: ByteArray = baos.toByteArray()
            val encodedImage: String = Base64.encodeToString(b, Base64.DEFAULT)
            // preferenceManager.setString("image_data", encodedImage)

            sharedPref.setImage(AppConstants.IMAGE, encodedImage)

            Log.e("sdfghj", "onActivityResult: " + imageBitmap)
        }
    }
    private fun getImageUriFromBitmap(context: Context, bitmap: Bitmap?): Uri? {
        if (bitmap == null) {
            return null
        }

        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)

        val imagePath = MediaStore.Images.Media.insertImage(
            context.contentResolver,
            bitmap,
            "File",
            null
        )

        return Uri.parse(imagePath)
    }


}


