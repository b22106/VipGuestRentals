package com.vipguestsrentals.Utils

object AppConstants {

    const val PREF_NAME = "Rentals"
    const val USER_DATA = "user_data"
    const val USER_ID = "user_id"
    const val ACCESS_TOKEN = "access_token"
    const val IMAGE        ="image"
    const val IS_ANSWERED = "is_answered"
    const val DEVICE_ID = "deviceID"
    const val FEEd_ID = "FeedID"
    const val ALL_PERMISSIONS = 22
    const val PICK_IMAGE_CAMERA = 1
    const val PICK_IMAGE_GALLERY = 2
    var AUTOCOMPLETE_REQUEST_CODE = 111
    var RATE_ON_GOOGLE = "rate_on_google"
    var TERM_CONDITIONS = "term_condition"
    var PRIVACY_POLICY = "privacy_policy"
    const val FACEBOOK = "1"
    const val GOOGLE = "2"
    const val LOOKING_TYPE = "lookingType"
    const val AGE_TYPE = "ageType"
    const val SPECIAL_NEED = "specialNeeds"
    const val BREED_PRIZE = "breedPrize"
    const val POSITION_QUESTION = "position_question"
    const val LASt_ANSWERED_POSITION = "last_answer"
    const val LAST_RESULTS = "lastResult"
    const val LOCATION_REQUEST = 1000
    const val LAST_RESULT = "lastREsultList"
}