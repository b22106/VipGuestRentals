package com.vipguestsrentals

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {
    lateinit var bottomNavigation : BottomNavigationView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        supportFragmentManager.beginTransaction().replace(R.id.homeContainer,Home_fragment()).commit()

        supportActionBar?.hide()
        bottomNavigation = findViewById(R.id.bottomNavigation)
        bottomNavigation.setOnItemSelectedListener {

            val fragment: Fragment

            when (it.itemId) {

                R.id.home -> {

                    fragment = Home_fragment()
                    supportFragmentManager.beginTransaction().replace(R.id.homeContainer, fragment).commit()

                    true
                }
                R.id.profile -> {
                    fragment = ProfileFragment()
                    supportFragmentManager.beginTransaction().replace(R.id.homeContainer, fragment).addToBackStack(null).commit()

                    true
                }

                else -> false
            }
        }
    }
}