package com.vipguestsrentals.SignUpActivity

import Retrofit_class
import android.annotation.SuppressLint
import android.app.admin.SystemUpdateInfo
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vipguestsrentals.ModelClass.SignupModel
import com.vipguestsrentals.R
import com.vipguestsrentals.SignInActivity.SignInActivity
import com.vipguestsrentals.databinding.ActivitySignUpBinding
import retrofit2.Call
import retrofit2.Response

class SignUpActivity : AppCompatActivity() {
    lateinit var binding: ActivitySignUpBinding
    private var isPasswordVisible = false
    private var isConfirmPassword = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        listiner()
    }

    private fun listiner() {

        binding.signup.setOnClickListener {
            val email:String = binding.Email.text.toString().trim()
            val password: String = binding.password.text.toString().trim()
            val confirmpassword: String = binding.ConfirmPassword.text.toString().trim()


            if (binding.FirstName.text.isEmpty()) {

                Toast.makeText(baseContext, "Please Enter First Name", Toast.LENGTH_SHORT).show()

            } else if (binding.LastName.text.isEmpty()) {

                Toast.makeText(baseContext, "Please Enter Last Name", Toast.LENGTH_SHORT).show()


            } else if (email.isEmpty()) {

                Toast.makeText(baseContext, "Please Enter Email id", Toast.LENGTH_SHORT).show()


            } else if (!Patterns.EMAIL_ADDRESS.matcher(binding.Email.text.toString()).matches()) {

                Toast.makeText(baseContext, "Please Enter Valid Email id !", Toast.LENGTH_SHORT)
                    .show()
            } else if (TextUtils.isEmpty(password)) {
                binding.password.error = "Please enter password"
            }else if(TextUtils.isEmpty(confirmpassword)){
                binding.ConfirmPassword.error="Please repeat password"
            }else if(password != confirmpassword) {
                binding.ConfirmPassword.error="Passwords don´t match"
            }else if (password.length < 6){
                binding.password.error = "Password must have atleast 6 caracters"

            } else {
                getSignup(
                    binding.FirstName.text.toString(),
                    binding.LastName.text.toString(),
                    binding.Email.text.toString(),
                    password,
                    confirmpassword
                )
            }

        }
        binding.eyeImg.setOnClickListener {
            if (isPasswordVisible) {
                binding.password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                binding.eyeImg.setImageResource(R.drawable.open_eye);
            } else {
                binding.password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                binding.eyeImg.setImageResource(R.drawable.eye_close);
            }
            isPasswordVisible = !isPasswordVisible;
            binding.password.setSelection(binding.password.text.length);
        }
        binding.CeyeImg.setOnClickListener {
            if (isConfirmPassword) {
                binding.ConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                binding.CeyeImg.setImageResource(R.drawable.open_eye);
            } else {
                binding.ConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                binding.CeyeImg.setImageResource(R.drawable.eye_close);
            }
            isConfirmPassword = !isConfirmPassword;
            binding.ConfirmPassword.setSelection(binding.ConfirmPassword.text.length);
        }
    }

    private fun getSignup(
        fname: String, lname: String, email: String, password: String, confirmpassword: String
    ) {
        val model =
            Retrofit_class.apiService.getSignup(fname, lname, email, password, confirmpassword)
        model?.enqueue(object : retrofit2.Callback<SignupModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<SignupModel?>, response: Response<SignupModel?>
            ) {
                if (response.isSuccessful) {
                    val signupModel: SignupModel = response.body()!!
                    if (signupModel.status == 201) {
                        Toast.makeText(baseContext, "SignUp Successful", Toast.LENGTH_SHORT).show()
                        val intent = Intent(baseContext, SignInActivity::class.java)
                        startActivity(intent)
                        finishAffinity()
                    } else {
                        Toast.makeText(
                            baseContext, "else" + signupModel.message.toString(), Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(
                        baseContext, "Email already exist" + response.message(), Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<SignupModel?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
            }

        })
    }
}