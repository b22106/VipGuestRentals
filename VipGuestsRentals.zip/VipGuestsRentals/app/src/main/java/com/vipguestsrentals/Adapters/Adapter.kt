package com.bittu.designapps.Adapters

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.vipguestsrentals.ModelClass.Links
import com.vipguestsrentals.R
import com.vipguestsrentals.WebViewActivity

class Adapter(private var context: Context, private val listItem: List<Links>) :
    RecyclerView.Adapter<Adapter.ViewHolder>() {
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvLink=itemView.findViewById<TextView>(R.id.Link_address)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_url, parent, false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listItem.size
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @SuppressLint("SuspiciousIndentation")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.apply {
            tvLink.text=listItem[position].name

            tvLink.setOnClickListener {
                var link=listItem[position]

                val i = Intent(context, WebViewActivity::class.java)
                i.putExtra("url",listItem[position].links)
                context.startActivity(i)

            }
        }
    }

}



