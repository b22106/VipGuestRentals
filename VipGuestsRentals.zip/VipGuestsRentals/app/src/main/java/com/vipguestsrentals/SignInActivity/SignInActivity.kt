package com.vipguestsrentals.SignInActivity

import Retrofit_class
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vipguestsrentals.ForgetPassword.ForgetPassword
import com.vipguestsrentals.HomeActivity
import com.vipguestsrentals.ModelClass.LoginModel
import com.vipguestsrentals.R
import com.vipguestsrentals.SignUpActivity.SignUpActivity
import com.vipguestsrentals.Utils.AppConstants
import com.vipguestsrentals.Utils.SharedPref
import com.vipguestsrentals.databinding.ActivitySignInBinding
import retrofit2.Call
import retrofit2.Response

class SignInActivity : AppCompatActivity() {
    lateinit var binding: ActivitySignInBinding
    lateinit var sharedPref: SharedPref
    private var isPasswordVisible = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
        listiner()
    }

    private fun inti() {
        sharedPref = SharedPref(this)
    }

    private fun listiner() {
        binding.eyeImg.setOnClickListener {
            if (isPasswordVisible) {
                binding.password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                binding.eyeImg.setImageResource(R.drawable.open_eye);
            } else {
                binding.password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                binding.eyeImg.setImageResource(R.drawable.eye_close);
            }
            isPasswordVisible = !isPasswordVisible;
            binding.password.setSelection(binding.password.text.length);
        }

        binding.signupTxt.setOnClickListener {
            var intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }
        binding.signin.setOnClickListener {
            val password: String = binding.password.text.toString().trim()

            if (binding.email.text.isEmpty()) {
                Toast.makeText(baseContext, "Please Enter Email id", Toast.LENGTH_SHORT).show()
            } else if (!Patterns.EMAIL_ADDRESS.matcher(binding.email.text.toString()).matches()) {
                binding.email.error = "Invalid email format"
            } else if (TextUtils.isEmpty(password)) {
                binding.password.error = "Please enter password"
            } else if (password.length < 6) {
                binding.password.error = "Password must have atleast 6 caracters"
            } else {
                getSignin(binding.email.text.toString(), binding.password.text.toString())
            }
        }

        binding.forgetPassword.setOnClickListener {
            val intent = Intent(this, ForgetPassword::class.java)
            startActivity(intent)
        }
    }

    private fun getSignin(email: String, password: String) {

        val model = Retrofit_class.apiService.getLogin(email, password)
        model?.enqueue(object : retrofit2.Callback<LoginModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<LoginModel?>,
                response: Response<LoginModel?>
            ) {
                if (response.isSuccessful) {
                    val loginModel: LoginModel = response.body()!!
                    if (loginModel.status == 201) {
                        sharedPref.setToken(AppConstants.ACCESS_TOKEN, loginModel.token)
                        Toast.makeText(baseContext, "Login Successful", Toast.LENGTH_SHORT).show()
                        val intent = Intent(baseContext, HomeActivity::class.java)
                        startActivity(intent)
                        finishAffinity()
                    } else {
                        Toast.makeText(
                            baseContext,
                            "" + loginModel.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(
                        baseContext,
                        "Not Authorized" + response.message(),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<LoginModel?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
            }

        })

    }
}