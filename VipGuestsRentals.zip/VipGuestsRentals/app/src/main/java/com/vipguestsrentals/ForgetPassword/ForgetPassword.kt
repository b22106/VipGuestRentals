package com.vipguestsrentals.ForgetPassword

import Retrofit_class
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vipguestsrentals.ModelClass.SendOtpModel
import com.vipguestsrentals.OTP_Verification
import com.vipguestsrentals.databinding.ActivityForgetPasswordBinding
import retrofit2.Call
import retrofit2.Response

class ForgetPassword : AppCompatActivity(), View.OnClickListener {
    lateinit var binding: ActivityForgetPasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgetPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        listiner()
    }

    private fun listiner() {
        binding.forgetPassword.setOnClickListener(this)
        binding.forgetImgBack.setOnClickListener(this)

    }

    private fun getforgetpassword(email: String) {
        Log.e("getforgetpassword", "getforgetpassword: " + email)

        val model = Retrofit_class.apiService.getotp(email)
        model?.enqueue(object : retrofit2.Callback<SendOtpModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<SendOtpModel?>, response: Response<SendOtpModel?>
            ) {
                if (response.isSuccessful) {
                    val resetPassword: SendOtpModel = response.body()!!
                    if (resetPassword.status == 200) {
                        Toast.makeText(baseContext, "" + resetPassword.message, Toast.LENGTH_SHORT)
                            .show()

                        var intent = Intent(baseContext, OTP_Verification::class.java)
                        intent.putExtra("email", email)
                        startActivity(intent)
                    } else {
                        Toast.makeText(
                            baseContext,
                            "" + resetPassword.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(baseContext, "" + response.message(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<SendOtpModel?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
            }

        })


    }

    override fun onClick(view: View?) {
        if (view === binding.forgetPassword) {
            if (binding.EnterEmail.text.isEmpty()) {
                Toast.makeText(baseContext, "Please Enter Email id", Toast.LENGTH_SHORT).show()

            } else if (!Patterns.EMAIL_ADDRESS.matcher(binding.EnterEmail.text.toString())
                    .matches()
            ) {

                Toast.makeText(baseContext, "Please Enter Valid Email id !", Toast.LENGTH_SHORT)
                    .show()
            } else {
                // getforgetpassword(Enter_Email.text.toString())

                var intent = Intent(baseContext, OTP_Verification::class.java)
                intent.putExtra("email", binding.EnterEmail.text.toString())
                startActivity(intent)

            }
        } else if (view === binding.forgetImgBack) {
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}