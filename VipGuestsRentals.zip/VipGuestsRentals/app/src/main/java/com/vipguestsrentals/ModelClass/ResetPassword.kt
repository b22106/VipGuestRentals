package com.vipguestsrentals.ModelClass

import com.google.gson.annotations.SerializedName

data class ResetPassword(
    @SerializedName("message" ) var message : String? = null

)
