package com.vipguestsrentals.Utils

import android.app.Application
import com.vipguestsrentals.Utils.SharedPref

class ApplicationGlobal:Application() {
    override fun onCreate() {
        super.onCreate()
        SharedPref(applicationContext)

    }
}