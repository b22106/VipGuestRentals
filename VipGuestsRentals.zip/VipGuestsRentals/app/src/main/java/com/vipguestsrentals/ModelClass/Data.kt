package com.vipguestsrentals.ModelClass

class Data {
}