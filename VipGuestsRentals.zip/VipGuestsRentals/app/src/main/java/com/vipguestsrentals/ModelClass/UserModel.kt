package com.vipguestsrentals.ModelClass


data class UserModel(

    val data: Datas,
    val message: String,
    val status: Int

)

data class Datas (val fname:String,val lname:String,val email:String)