package com.vipguestsrentals.Utils

import android.content.Context
import android.content.SharedPreferences

class SharedsCommon(context: Context) {
        private val sharedpreferences: SharedPreferences

        companion object {
            lateinit var instance: SharedsCommon
                private set
        }

        init {
            instance = this
            sharedpreferences = context.getSharedPreferences(AppConstants.PREF_NAME, Context.MODE_PRIVATE)
        }


        fun setImage(name: String?, value: String?) {
            sharedpreferences.edit().putString(name, value).apply()
        }

        fun getImage(image: String?): String? {
            return sharedpreferences.getString(image, "")
        }

        fun clear() {
            sharedpreferences.edit().clear().apply()
        }

        var locationList: String?
            get() = sharedpreferences.getString("LocationList", "")
            set(list) {
                sharedpreferences.edit().putString("LocationList", list).apply()
            }


}