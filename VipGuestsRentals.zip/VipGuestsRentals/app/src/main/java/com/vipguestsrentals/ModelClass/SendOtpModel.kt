package com.vipguestsrentals.ModelClass

import com.google.gson.annotations.SerializedName

data class SendOtpModel(
    @SerializedName("status")   var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null

)
