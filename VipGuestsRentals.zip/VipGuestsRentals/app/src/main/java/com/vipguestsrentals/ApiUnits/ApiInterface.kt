
import com.vipguestsrentals.ModelClass.*
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*


interface  ApiInterface {


    @FormUrlEncoded
    @POST("api/signup")
    fun getSignup(
        @Field("fname") fname:String?,
        @Field("lname") lname:String?,
        @Field("email") email:String?,
        @Field("password") password:String?,
        @Field("c_password") c_password:String?,
    ): Call<SignupModel>?

    @FormUrlEncoded
    @POST("api/login")
    fun getLogin(
        @Field("email") email:String?,
        @Field("password") password:String?,
    ): Call<LoginModel>?

    @FormUrlEncoded
    @POST("api/change_password")
    fun getChangePassword(
        @Field("old_password") old_password:String?,
        @Field("password") password:String?,
        @Field("c_password") c_password:String?,

        ): Call<ChangePasswordModel>?

    @FormUrlEncoded
    @POST("api/profile")
    fun getprofileUpdate(
        @Field("fname") fname:String?,
        @Field("lname") lname:String?,
        @Field("email") email:String?,
        ): Call<ChangePasswordModel>?

    @FormUrlEncoded
    @POST("api/request_otp")
    fun getResetPassword(
        @Field("email") email:String?,
    ): Call<ResetPassword>?


    @GET("api/get-links")
    fun getLinks():Call<GetLinksResponse>

    @GET("api/get-user")
    fun getuser():Call<UserModel?>


    @POST("api/logout")
    fun logout():Call<ChangePasswordModel>

    @Multipart
    @POST("api/get-user")
    fun updateImage(
        @Part profile_pic: MultipartBody.Part,
    ):Call<ImageModal>

    @FormUrlEncoded
    @POST("api/get-user")
    fun getProfileImage():Call<ChangePasswordModel>

    @FormUrlEncoded
    @POST("api/request_otp")
    fun getotp(
        @Field("email") email:String?
    ):Call<SendOtpModel?>

    @FormUrlEncoded
    @POST("api/verify_otp")
    fun getVerifyotp(
        @Field("email") email:String?,
        @Field("otp")   otp:String?
    ):Call<VerifyOtpModel?>


    @GET("api/otp_password")
    fun getNewPassword(
        @Query("password") password:String?,
        @Query("c_password") c_password:String?,
        ): Call<ResetNewPassword>?
}