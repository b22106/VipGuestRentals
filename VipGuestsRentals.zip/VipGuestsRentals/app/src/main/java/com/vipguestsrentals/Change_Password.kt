package com.vipguestsrentals

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.Toast
import com.vipguestsrentals.ModelClass.ChangePasswordModel
import com.vipguestsrentals.databinding.ActivityChangePasswordBinding

import retrofit2.Call
import retrofit2.Response

class Change_Password : AppCompatActivity() {
    lateinit var binding: ActivityChangePasswordBinding

    private var isPasswordVisible = false
    private var isConfirmPassword=false

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityChangePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.updatepassword.setOnClickListener {

            if(binding.oldpassword.text.isEmpty()){
                Toast.makeText(baseContext, "Please Enter Old Password", Toast.LENGTH_SHORT).show()

            }else if(binding.password.text.isEmpty()){
                Toast.makeText(baseContext, "Please Enter New Password", Toast.LENGTH_SHORT).show()

            }else if(binding.ConfirmPassword.text.isEmpty()){
                Toast.makeText(baseContext, "Please Enter Confirm Password", Toast.LENGTH_SHORT).show()

            }
            else{
                getUpdatePassword(binding.oldpassword.text.toString(),binding.password.text.toString(),binding.ConfirmPassword.text.toString())
            }
        }
        binding.eyeImg.setOnClickListener {

            if (isPasswordVisible) {
                binding.password.transformationMethod = PasswordTransformationMethod.getInstance();
                binding.eyeImg.setImageResource(R.drawable.open_eye)
            } else {
                binding.password.transformationMethod = HideReturnsTransformationMethod.getInstance();
                binding.eyeImg.setImageResource(R.drawable.eye_close)
            }
            isPasswordVisible = !isPasswordVisible;
            binding.password.setSelection(binding.password.text.length)
        }

        binding.CeyeImg.setOnClickListener {
            if (isConfirmPassword) {
                binding.ConfirmPassword.transformationMethod = PasswordTransformationMethod.getInstance();
                binding.CeyeImg.setImageResource(R.drawable.open_eye)
            } else {
                binding.ConfirmPassword.transformationMethod = HideReturnsTransformationMethod.getInstance();
                binding.CeyeImg.setImageResource(R.drawable.eye_close)
            }
            isConfirmPassword = !isConfirmPassword;
            binding.ConfirmPassword.setSelection( binding.ConfirmPassword.text.length)
        }
    }
    private fun getUpdatePassword(oldpassword: String, password: String, cpassword: String) {

        val model= Retrofit_class.apiService.getChangePassword(oldpassword,password,cpassword)
        model?.enqueue(object :retrofit2.Callback<ChangePasswordModel?>{
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<ChangePasswordModel?>,
                response: Response<ChangePasswordModel?>
            ) {
                if (response.isSuccessful) {
                    val changePasswordModel: ChangePasswordModel = response.body()!!
                    if (changePasswordModel.message=="Password has been changed successfully") {
                        Toast.makeText(baseContext, "Password has been changed successfully", Toast.LENGTH_SHORT).show()
                    }

                    else{
                        Toast.makeText(baseContext, "" +changePasswordModel.message.toString(), Toast.LENGTH_SHORT).show()
                    }

                } else {

                    Toast.makeText(baseContext, "" + response.message(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ChangePasswordModel?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
            }

        })


    }
}