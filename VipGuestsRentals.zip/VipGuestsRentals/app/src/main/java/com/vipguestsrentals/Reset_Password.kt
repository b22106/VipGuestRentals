package com.vipguestsrentals

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Log

import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vipguestsrentals.ModelClass.ResetNewPassword
import com.vipguestsrentals.SignInActivity.SignInActivity
import com.vipguestsrentals.Utils.SharedPref
import com.vipguestsrentals.databinding.ActivityResetPasswordBinding
import retrofit2.Call
import retrofit2.Response

class Reset_Password : AppCompatActivity() {
    lateinit var binding: ActivityResetPasswordBinding
    private var isPasswordVisible = false
    private var isConfirmPassword = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResetPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        listiner()

    }

    private fun listiner() {
        binding.resetImgBack.setOnClickListener {
            finish()
        }
        binding.savePassword.setOnClickListener {
            val password = binding.resetPassword.text.toString().trim()
            val cpassword = binding.resetConfirmPassword.text.toString().trim()
            if (password.isEmpty()) {
                binding.resetPassword.error = "Password Required"
                return@setOnClickListener
                Toast.makeText(baseContext, "Please Enter Password", Toast.LENGTH_SHORT).show()
            } else if (cpassword.isEmpty()) {
                binding.resetConfirmPassword.error = "confirm password"
                Toast.makeText(baseContext, "Please Enter Confirm Password", Toast.LENGTH_SHORT).show()
            } else {
                changeNewPassword(password, cpassword)
            }
        }
        binding.eyeImg.setOnClickListener {

            if (isPasswordVisible) {
                // Hide the password
                binding.resetPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                binding.eyeImg.setImageResource(R.drawable.open_eye);
            } else {
                // Show the password
                binding.resetPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                binding.eyeImg.setImageResource(R.drawable.eye_close);
            }

            // Toggle the flag
            isPasswordVisible = !isPasswordVisible;

            // Move cursor to the end of the text
            binding.resetPassword.setSelection(binding.resetPassword.text.length);
        }

        binding.CeyeImg.setOnClickListener {
            if (isConfirmPassword) {
                // Hide the password
                binding.resetConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                binding.CeyeImg.setImageResource(R.drawable.open_eye);
            } else {
                // Show the password
                binding.resetConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                binding.CeyeImg.setImageResource(R.drawable.eye_close);
            }

            // Toggle the flag
            isConfirmPassword = !isConfirmPassword;

            // Move cursor to the end of the text
            binding.resetConfirmPassword.setSelection(binding.resetConfirmPassword.text.length);
        }
    }
    private fun changeNewPassword(password: String, cpassword: String) {
//        Log.e("verifyOtp", "verifyOtp: " + password)
//        Log.e("verifyOtp", "verifyOtp: " + cpassword)

        val model = Retrofit_class.apiService.getNewPassword(password, cpassword)
        model?.enqueue(object : retrofit2.Callback<ResetNewPassword?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<ResetNewPassword?>,
                response: Response<ResetNewPassword?>
            ) {
                if (response.isSuccessful) {
                    val resetPassword: ResetNewPassword = response.body()!!
                    if (resetPassword.status == 200) {
                        Log.e("getResponse", "onResponse: " + resetPassword.message)
                        Toast.makeText(baseContext, "" + resetPassword.message, Toast.LENGTH_SHORT).show()
                        SharedPref.instance.clear()
                        val intent = Intent(baseContext, SignInActivity::class.java)
                        startActivity(intent)

                    } else {
                        Toast.makeText(
                            baseContext,
                            "" + resetPassword.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(baseContext, "" + response.message(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResetNewPassword?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
                Log.e("getResponse", "onResponse: " + t)

            }

        })
    }


}