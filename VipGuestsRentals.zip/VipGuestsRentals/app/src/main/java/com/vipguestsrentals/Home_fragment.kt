package com.vipguestsrentals

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bittu.designapps.Adapters.Adapter
import com.vipguestsrentals.ModelClass.GetLinksResponse
import com.vipguestsrentals.ModelClass.Links
import retrofit2.Call
import retrofit2.Response

class Home_fragment : Fragment() {
    lateinit var recHome:RecyclerView
    lateinit var adapterLinks:Adapter
    var listLinks=ArrayList<Links>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        val view= inflater.inflate(R.layout.fragment_home_fragment, container, false)
        recHome=view.findViewById(R.id.recyclerviewHome)
        adapterLinks=Adapter(requireContext(),listLinks)
        recHome.adapter=adapterLinks
        getLinks()
        return view

    }

    private fun getLinks() {

        val model= Retrofit_class.apiService.getLinks()
        model.enqueue(object :retrofit2.Callback<GetLinksResponse?>{
            @SuppressLint("SuspiciousIndentation", "NotifyDataSetChanged")
            override fun onResponse(
                call: Call<GetLinksResponse?>,
                response: Response<GetLinksResponse?>
            ) {
                if (response.isSuccessful) {
                    val getlinksdata: GetLinksResponse = response.body()!!
                    if (getlinksdata.status==201) {
                        listLinks.clear()
                        listLinks.addAll(getlinksdata.links)
                        adapterLinks.notifyDataSetChanged()

                    } else{
                        Toast.makeText(requireContext(), "" , Toast.LENGTH_SHORT).show()
                    }

                } else {

                    Toast.makeText(requireContext(), "" + response.message(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<GetLinksResponse?>, t: Throwable) {
                Toast.makeText(requireContext(), "" + t, Toast.LENGTH_SHORT).show()
            }

        })


    }
}