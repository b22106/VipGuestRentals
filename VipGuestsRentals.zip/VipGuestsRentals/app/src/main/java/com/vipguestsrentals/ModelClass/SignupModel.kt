package com.vipguestsrentals.ModelClass

import com.google.gson.annotations.SerializedName


data class SignupModel (

    @SerializedName("token"   ) var token   : String? = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("status"  ) var status  : Int?    = null

)