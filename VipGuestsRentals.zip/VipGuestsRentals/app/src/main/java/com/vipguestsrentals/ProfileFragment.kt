package com.vipguestsrentals
import Retrofit_class
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.vipguestsrentals.ModelClass.ChangePasswordModel
import com.vipguestsrentals.ModelClass.UserModel
import com.vipguestsrentals.SignInActivity.SignInActivity
import com.vipguestsrentals.SubscriptionActivity.SubscriptionActivity
import com.vipguestsrentals.Utils.AppConstants
import com.vipguestsrentals.Utils.SharedPref
import com.vipguestsrentals.Utils.SharedsCommon
import com.vipguestsrentals.databinding.FragmentProfileBinding
import retrofit2.Call
import retrofit2.Response


class ProfileFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentProfileBinding
    lateinit var fragment: Fragment
    lateinit var sharedPref: SharedsCommon


    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentProfileBinding.inflate(layoutInflater, container, false)
        sharedPref = SharedsCommon(requireContext())
        val abc = sharedPref.getImage(AppConstants.IMAGE)

        if (!abc.toString().isEmpty()) {
            val b: ByteArray = Base64.decode(abc, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(b, 0, b.size)
            binding.profile.setImageBitmap(bitmap)
        }

        ClickListener()
        getUsers()
        return binding.root
    }

    private fun ClickListener() {
        binding.logout.setOnClickListener(this)
        binding.editprofile.setOnClickListener(this)
        binding.privacyPolicy.setOnClickListener(this)
        binding.termsConditions.setOnClickListener(this)
        binding.subscription.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.logout -> {
                val builder1: AlertDialog.Builder = AlertDialog.Builder(context)
                builder1.setMessage("Are you sure, you want to logout?")
                builder1.setCancelable(true)

                builder1.setPositiveButton(
                    "Yes",
                    { dialog, id ->
                        dialog.cancel()
                        logout()
                    })

                builder1.setNegativeButton(
                    "No",
                    { dialog, id -> dialog.cancel() })

                val alert11: AlertDialog = builder1.create()
                alert11.show()
            }

            R.id.editprofile -> {
                fragment = EditProfileFragment()
                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.homeContainer, fragment).commit()
            }

            R.id.privacy_policy -> {
                val uri2 =
                    Uri.parse("https://www.lookandbookvip.com/privacy-policy") // missing 'http://' will cause crashed
                val intent2 = Intent(Intent.ACTION_VIEW, uri2)
                startActivity(intent2)

            }

            R.id.terms_conditions -> {
                val uri2 =
                    Uri.parse("https://www.lookandbookvip.com/privacy-policy") // missing 'http://' will cause crashed
                val intent2 = Intent(Intent.ACTION_VIEW, uri2)
                startActivity(intent2)
            }

            R.id.subscription -> {
                val intent = Intent(requireContext(), SubscriptionActivity::class.java)
                startActivity(intent)
            }

        }
    }

    private fun logout() {
        val model = Retrofit_class.apiService.logout()
        model.enqueue(object : retrofit2.Callback<ChangePasswordModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<ChangePasswordModel?>,
                response: Response<ChangePasswordModel?>
            ) {
                if (response.isSuccessful) {
                    //                     val getlinksdata: ChangePasswordModel = response.body()!!
                    SharedPref.instance.clear()
                    val i = Intent(context, SignInActivity::class.java)
                    startActivity(i)
                    activity?.finish()
                } else {
                    Toast.makeText(requireContext(), "" + response.message(), Toast.LENGTH_SHORT)
                        .show()
                }
            }

            override fun onFailure(call: Call<ChangePasswordModel?>, t: Throwable) {
                Toast.makeText(requireContext(), "" + t, Toast.LENGTH_SHORT).show()
            }

        })


    }

    private fun getUsers() {

        val model = Retrofit_class.apiService.getuser(
        )
        model.enqueue(object : retrofit2.Callback<UserModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<UserModel?>,
                response: Response<UserModel?>
            ) {
                if (response.isSuccessful) {
                    val getlinksdata: UserModel? = response.body()!!
                    if (getlinksdata?.status == 201) {
                        binding.userName.text = getlinksdata.data.fname
                            .plus(" " + getlinksdata.data.lname)

                    } else {
                        Toast.makeText(
                            requireContext(),
                            getlinksdata?.message ?: "",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {
                    response.errorBody()?.let { body ->
                        try {
                            val resType = object : TypeToken<UserModel>() {}.type
                            val errBody: UserModel? =
                                Gson().fromJson(body.charStream(), resType)

                            Log.e("errorBody: ", "${errBody?.message}")
                            Toast.makeText(
                                requireContext(),
                                errBody?.message ?: "",
                                Toast.LENGTH_SHORT
                            ).show()

                        } catch (e: Exception) {
                            Log.e("errorBody: ", "${e.message}")
                            Toast.makeText(
                                requireContext(),
                                e.localizedMessage!!.toString(),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                }
            }

            override fun onFailure(call: Call<UserModel?>, t: Throwable) {
                Toast.makeText(requireContext(), "" + t, Toast.LENGTH_SHORT).show()
            }

        })


    }
    /*private fun getUsers() {

        val model = Retrofit_class.apiService.getuser(
        )
        model?.enqueue(object : retrofit2.Callback<UserModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<UserModel?>,
                response: Response<UserModel?>
            ) {
                if (response.isSuccessful) {
                    val getlinksdata: UserModel? = response.body()!!
                    if (getlinksdata?.status == 201) {
                        username.text = getlinksdata?.data?.fname.toString()
                            .plus(" " + getlinksdata?.data?.lname.toString())

                    } else {
                        Toast.makeText(
                            requireContext(),
                            getlinksdata?.message ?: "",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {
                    response.errorBody()?.let { body ->
                        try {
                            val resType = object : TypeToken<UserModel>() {}.type
                            val errBody: UserModel? =
                                Gson().fromJson(body.charStream(), resType)

                            Log.e("errorBody: ", "${errBody?.message}")
                            Toast.makeText(
                                requireContext(),
                                errBody?.message ?: "",
                                Toast.LENGTH_SHORT
                            ).show()

                        } catch (e: Exception) {
                            Log.e("errorBody: ", "${e.message}")
                            Toast.makeText(
                                requireContext(),
                                e.localizedMessage!!.toString() ?: "",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                }
            }

            override fun onFailure(call: Call<UserModel?>, t: Throwable) {
                Toast.makeText(requireContext(), "" + t, Toast.LENGTH_SHORT).show()
            }

        })


    }*/

}