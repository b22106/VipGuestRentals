package com.vipguestsrentals.ModelClass

import com.google.gson.annotations.SerializedName


data class getotp(
    @SerializedName("message") var message: String? = null
)
