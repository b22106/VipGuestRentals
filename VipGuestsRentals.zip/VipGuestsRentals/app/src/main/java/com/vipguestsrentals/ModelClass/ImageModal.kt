package com.vipguestsrentals.ModelClass

import com.google.gson.annotations.SerializedName


data class ImageModal (
    @SerializedName("url_image"  ) var url  : String? = null,
    @SerializedName("status")   var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
)