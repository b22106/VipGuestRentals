package com.vipguestsrentals

import Retrofit_class
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vipguestsrentals.ModelClass.SendOtpModel
import com.vipguestsrentals.ModelClass.VerifyOtpModel
import com.vipguestsrentals.Utils.AppConstants
import com.vipguestsrentals.Utils.SharedPref
import com.vipguestsrentals.databinding.ActivityOtpVerificationBinding
import retrofit2.Call
import retrofit2.Response

class OTP_Verification : AppCompatActivity(), View.OnClickListener {
    lateinit var binding: ActivityOtpVerificationBinding
    lateinit var sharedPref: SharedPref
    var email: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOtpVerificationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
        listiner()
        email = intent.getStringExtra("email")
        binding.tvEmail.setText(email)
        getforgetpassword(email.toString())

    }

    private fun listiner() {
        binding.otpSubmitBtn.setOnClickListener(this)
        binding.tvResendOtp.setOnClickListener(this)
        binding.otpImgBack.setOnClickListener(this)
    }

    private fun inti() {
        sharedPref = SharedPref(this)
    }

    private fun getforgetpassword(email: String) {

        Log.e("getforgetpassword", "getforgetpassword: " + email)

        val model = Retrofit_class.apiService.getotp(email)
        model?.enqueue(object : retrofit2.Callback<SendOtpModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<SendOtpModel?>,
                response: Response<SendOtpModel?>
            ) {
                if (response.isSuccessful) {
                    val resetPassword: SendOtpModel = response.body()!!
                    if (resetPassword.status == 200) {
                        Toast.makeText(baseContext, "" + resetPassword.message, Toast.LENGTH_SHORT)
                            .show()

                        Log.e("sdfgh", "onResponse: " + resetPassword.message)
                    } else {
                        Toast.makeText(
                            baseContext,
                            "" + resetPassword.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(baseContext, "" + response.message(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<SendOtpModel?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
            }

        })
    }


    override fun onClick(view: View?) {
        if (view === binding.otpSubmitBtn) {
            if (binding.otpView.otp.isEmpty()) {

                Toast.makeText(baseContext, "Please Enter Password", Toast.LENGTH_SHORT).show()

            } else {
                verifyOtp(email, binding.otpView.otp.toString())
                Log.e("verifyOtp", "verifyOtp: " + binding.otpView.otp)


            }

        } else if (view === binding.tvResendOtp) {
            resend_otp()
        } else if (view === binding.otpImgBack) {
            finish()
        }
    }

    private fun resend_otp() {
        val model = Retrofit_class.apiService.getotp(email)
        model.enqueue(object : retrofit2.Callback<SendOtpModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<SendOtpModel?>, response: Response<SendOtpModel?>
            ) {
                if (response.isSuccessful) {
                    val resetPassword: SendOtpModel = response.body()!!
                    if (resetPassword.status == 200) {
                        Toast.makeText(baseContext, "" + resetPassword.message, Toast.LENGTH_SHORT)
                            .show()


                    } else {
                        Toast.makeText(
                            baseContext,
                            "" + resetPassword.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(baseContext, "" + response.message(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<SendOtpModel?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
            }

        })

    }

    private fun verifyOtp(email: String?, otpView: String) {

        Log.e("verifyOtp", "verifyOtp: " + email)
        Log.e("verifyOtp", "verifyOtp: " + otpView)

        val model = Retrofit_class.apiService.getVerifyotp(email, otpView.toString())
        model.enqueue(object : retrofit2.Callback<VerifyOtpModel?> {
            @SuppressLint("SuspiciousIndentation")
            override fun onResponse(
                call: Call<VerifyOtpModel?>,
                response: Response<VerifyOtpModel?>
            ) {
                if (response.isSuccessful) {
                    val resetPassword: VerifyOtpModel = response.body()!!
                    if (resetPassword.status == 200) {
                        Toast.makeText(baseContext, "" + resetPassword.message, Toast.LENGTH_SHORT)
                            .show()
                        sharedPref.setToken(AppConstants.ACCESS_TOKEN, resetPassword.access_token)


                        val intent = Intent(baseContext, Reset_Password::class.java)
                        startActivity(intent)

                    } else {
                        Toast.makeText(
                            baseContext,
                            "" + resetPassword.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(baseContext, "" + response.message(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<VerifyOtpModel?>, t: Throwable) {
                Toast.makeText(baseContext, "" + t, Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

}