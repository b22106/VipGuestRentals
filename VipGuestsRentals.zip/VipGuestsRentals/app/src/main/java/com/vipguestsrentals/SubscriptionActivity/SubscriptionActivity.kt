package com.vipguestsrentals.SubscriptionActivity
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.vipguestsrentals.HomeActivity
import com.vipguestsrentals.R


class SubscriptionActivity : AppCompatActivity() {
    lateinit var back_sub:ImageView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subscription)
        back_sub=findViewById(R.id.back_sub)
        back_sub.setOnClickListener {
            finish()
        }
    }
}
