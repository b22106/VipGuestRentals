package com.vipguestsrentals.ModelClass

data class GetLinksResponse(
    val links: List<Links>,
    val message: String,
    val status: Int
)

data class Links (val name:String,val links:String)